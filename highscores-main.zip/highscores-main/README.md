# HighscoresInJavaFX
Sample project in Java for SWEN2 course, a simple GUI application with an observable list, MVVM and MVVM-Unit-Tests. 

## Included JUnit test:
- List handling
- JavaFX Table headers
- JavaFX table contents
- JavaFX table data changes
