package at.fhtw.highscores;

public interface FocusChangedListener {
    void requestFocusChange(String name);
}
